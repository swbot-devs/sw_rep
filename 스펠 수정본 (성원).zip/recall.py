import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import random
from selenium.common.exceptions import NoSuchElementException, TimeoutException


def run_recall(driver, num_d, da_e, da_kyn, time_2):
    print("리콜 학습을 시작합니다...")

    # 1. 학습 시작 버튼 클릭 (기존 로직 유지)
    try:
        start_btn = WebDriverWait(driver, 3).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "a.btn-opt-start"))
        )
        start_btn.click()
        print("학습 시작 버튼 클릭 성공")
    except TimeoutException:
        print(
            "학습 시작 버튼을 찾지 못했습니다. 이미 학습이 시작되었거나 다른 상태일 수 있습니다."
        )
    except Exception as e:
        print(f"학습 진입 중 오류 발생 (무시하고 진행): {e}")

    time.sleep(2)  # 학습 로딩 대기

    # 2. 문제 풀이 루프 (안정성 강화)
    for i in range(1, num_d + 1):  # 1부터 num_d까지
        print(f"--- {i}번째 카드 처리 시도 ---")

        try:
            # 현재 문제(단어/뜻) 텍스트 가져오기
            # 문제 텍스트를 찾을 때까지 최대 3초 대기
            question_ele = WebDriverWait(driver, 3).until(
                EC.visibility_of_element_located(
                    (
                        By.CSS_SELECTOR,
                        # 리콜 모드 문제 텍스트를 담을 가능성이 높은 선택자 추가 (클래스카드 기준)
                        ".study-body .CardItem.current .card-top .card-title, "
                        ".study-body .CardItem.current .card-top .spell-content",
                    )
                )
            )
            cash_d = question_ele.text.strip()
            # print(f"문제 단어 감지: '{cash_d}'")

        except TimeoutException:
            print(
                f"{i}번째 카드: 문제 단어를 찾을 수 없습니다. (학습 종료 화면 또는 로딩 지연 가능성)"
            )
            # 학습 종료 화면 감지 시 루프 종료
            try:
                driver.find_element(By.CSS_SELECTOR, ".end-opt-box")
                print("학습 종료 화면 감지. 리콜 학습 종료.")
                break
            except:
                time.sleep(2)
                continue
        except Exception as e:
            print(f"문제 단어 감지 오류 (카드 {i}): {e}")
            time.sleep(1)
            continue

        # 3. 보기(선택지) 3개 가져오기
        choices = driver.find_elements(
            By.CSS_SELECTOR,
            # 선택지 선택자 (가장 가능성 높은 두 가지)
            ".study-body .CardItem.current .card-bottom .recall-choices a.recall-choice, "
            ".study-body .CardItem.current .card-bottom .sel_item",
        )

        if choices:
            # 4-1. 선택지(객관식) 화면일 경우: 정답 찾기 및 클릭
            found_answer = False
            target_mean = ""

            try:
                # 단어장에서 정답 뜻 찾기
                idx = da_e.index(cash_d)
                target_mean = da_kyn[idx]
            except ValueError:
                print(
                    f"단어 '{cash_d}'를 단어장에서 찾을 수 없습니다. 랜덤 선택합니다."
                )

            # 보기 중에서 정답 클릭
            if target_mean:
                for choice in choices:
                    choice_text = choice.text.strip()
                    # 정답 매칭 확인
                    if target_mean in choice_text or choice_text in target_mean:
                        choice.click()
                        found_answer = True
                        # print(f"정답 선택 성공: '{target_mean}'")
                        break

            # 정답을 못 찾은 경우나 단어장에 없는 경우 랜덤 클릭
            if not found_answer:
                random.choice(choices).click()
                print(f"랜덤 선택함: 카드 단어 '{cash_d}'")

            time.sleep(time_2)  # 다음 문제 로딩 대기

        else:
            # 4-2. 선택지가 없을 경우: 답안 보기/넘기기 단계 처리
            print(f"{i}번째 카드: 선택지 미감지. 답안 공개/다음 단계 진행 시도.")

            # 시도 1: 카드 중앙 클릭 (답안 공개 단축키 시뮬레이션)
            try:
                card_center = WebDriverWait(driver, 1).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, ".CardItem.current"))
                )
                card_center.click()
                # print(f"카드 중앙 클릭 성공")
                time.sleep(0.5)  # 답안이 공개될 때까지 잠시 대기
            except TimeoutException:
                pass

            # 시도 2: '다음/알겠어요' 버튼 찾아서 클릭 (공개된 답을 인지하고 다음으로 넘어가는 버튼)
            try:
                # '다음(Next)' 버튼 또는 '알겠어요(I know)' 버튼 탐색
                next_btn = WebDriverWait(driver, 1).until(
                    EC.element_to_be_clickable(
                        (
                            By.CSS_SELECTOR,
                            "a.btnNext, a.btn-recall-i-know, a.btn-recall-i-dont-know",
                        )
                    )
                )
                next_btn.click()
                print(f"'다음/알겠어요' 버튼 클릭 성공")
            except TimeoutException:
                print(
                    f"{i}번째 카드: 다음 단계로 넘어갈 버튼을 찾지 못함. (해당 카드 스킵)"
                )

            time.sleep(time_2)
            continue  # 다음 카드로 진행

        # 오답 처리 후 '다음' 버튼이 뜰 경우를 대비한 최종 확인 (선택지 클릭 후 바로 넘어가기도 하지만, 오답 시 필요)
        try:
            next_btn_final = driver.find_element(By.CSS_SELECTOR, "a.btnNext")
            if next_btn_final.is_displayed():
                next_btn_final.click()
        except:
            pass

    print("리콜 학습이 완료되었습니다.")
