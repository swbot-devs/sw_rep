# learning_types/spelling.py
import time
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

def run_spelling(driver, num_d, da_e, da_k):
    print("스펠학습을 시작합니다...")
    time.sleep(1)

    try:
        for i in range(1, num_d):
            word_id = None
            word_result = None

            elem = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH,
                f"//*[@id='wrapper-learn']//div[@class='study-body fade  in']//div[@class='fade in']/div[{i}]")))
            word_id = elem.get_attribute("data-idx")

            # 숫자로 변환
            word_id = str(word_id)

            # 2) 브라우저에서 study_data 배열 가져오기 (JS 변수 읽기)
            study_data_js = driver.execute_script("return study_data;")

            # 3) Python에서 card_idx == word_id 인 객체 찾기
            for item in study_data_js:
                if str(item["card_idx"]) == word_id:
                    word_result = item["front"]
                    break

            print("word_id:", word_id)
            print("front 값(word_result):", word_result)

            text = word_result
            in_tag = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located(
                    (By.XPATH, f"//div[@data-idx={word_id}]//div[@class='text-normal spell-input']//input")
                )
            )
            print(in_tag)
            in_tag.click()
            print("1) 단어 입력창 클립 완료")
            in_tag.send_keys(text)
            print("2) 단어 입력 완료")
            driver.find_element(By.XPATH,"//*[@id='wrapper-learn']/div/div/div[3]/div[2]/div[2]/a").click()
            print("3) 확인 버튼 클릭 완료")
            time.sleep(1.5)
            try:
                driver.find_element(By.XPATH,"//*[@id='wrapper-learn']/div/div/div[3]/div[2]/div[3]/a").click()
                print("4) 다음 단어 버튼 클릭 완료")
            except: pass
            print(f"i = {i}")
            time.sleep(2)

    except TimeoutException: print("input 필드를 찾지 못했습니다. 모든 단어가 학습되었거나 구조가 변경되었습니다.")
    except NoSuchElementException: print("모든 단어가 학습되었습니다.")

    print("스펠학습이 완료되었습니다.")
